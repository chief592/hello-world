$(document).ready(function(){
    
    //STICKY MENU
    
    $(".js--services-section").waypoint(function(direction){
        
        if(direction == "down"){
           
            $("nav").addClass("sticky");
           
           }else{
               $("nav").removeClass("sticky");
           }
        
    });
    
    
    //MIXITUP(PORTFOIL SECTION)
    var mixer = mixitup('.container');
    
    
    // SMOOTH EDGE/ IE/ SAFARI
    
     $("a").on('click', function(event){
       event.preventDefault();
        
        var hash = this.hash;
        
        $('html, body').animate({
            scrollTop: $(hash).offset().top}, 800, function(){
            window.location.hash = hash;
        });
 
        
    });
    
    
    // MOBILE-NAV NAVIGATION PROBLEM IN IE
    
});

function openNav(){
    document.getElementById("myNav").style.width = "100%";
}

function closeNav(){
    document.getElementById("myNav").style.width = "0%";
}









